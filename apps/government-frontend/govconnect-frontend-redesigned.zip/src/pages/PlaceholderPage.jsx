import { ArrowLeft, Wrench } from "lucide-react";
import { useNavigate } from "react-router-dom";
import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";

function PlaceholderPage({ title, description }) {
  const navigate = useNavigate();

  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Government Intelligence Portal"
        title={title}
        description={description}
      />

      <section className="surface-card flex flex-col items-start gap-5 p-8 sm:p-10">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-100 text-accent-600">
          <Wrench size={26} />
        </div>

        <div>
          <div className="mb-2 flex items-center gap-2">
            <Badge tone="accent">Pending backend integration</Badge>
          </div>

          <p className="max-w-2xl text-sm leading-6 text-navy-500">
            This module&apos;s interface is designed and ready. It will
            populate with live data as soon as the corresponding API
            endpoint is connected — no further frontend changes will be
            required.
          </p>
        </div>

        <Button variant="secondary" icon={ArrowLeft} onClick={() => navigate("/")}>
          Back to Dashboard
        </Button>
      </section>
    </DashboardLayout>
  );
}

export default PlaceholderPage;
