import { useEffect, useState } from "react";
import { BarChart3, RefreshCw, TrendingUp, Activity } from "lucide-react";

import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import Button from "../components/ui/Button";
import MetricCard from "../components/cards/MetricCard";
import AnalyticsCard from "../components/cards/AnalyticsCard";
import SectorDemandChart from "../components/charts/SectorDemandChart";
import SkillGapChart from "../components/charts/SkillGapChart";
import { LoadingState } from "../components/ui/States";

import { getHighestSkilledSectors, getSkillGap } from "../services/governmentService";

const Analytics = () => {
  const [sectors, setSectors] = useState([]);
  const [skillGap, setSkillGap] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setLoading(true);

    try {
      const sectorsData = await getHighestSkilledSectors();
      const gapData = await getSkillGap();

      setSectors(Array.isArray(sectorsData.data) ? sectorsData.data : []);
      setSkillGap(Array.isArray(gapData.data) ? gapData.data : []);
    } catch (error) {
      console.error("Failed to load analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Data Intelligence"
        title="Government Analytics"
        description="Explore sector-level skill distribution and identify gaps between available skills and industry demand."
        icon={BarChart3}
        actions={
          <Button variant="secondary" icon={RefreshCw} onClick={loadAnalytics}>
            Refresh
          </Button>
        }
      />

      {/* Summary strip */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <MetricCard icon={BarChart3} title="Sector Records" value={sectors.length} loading={loading} />
        <MetricCard icon={Activity} title="Skill Records" value={skillGap.length} loading={loading} />
        <MetricCard
          icon={TrendingUp}
          title="Data Status"
          value={loading ? "Loading" : "Updated"}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <AnalyticsCard
          label="Sector Intelligence"
          title="Highest Skilled Sectors"
          description="Distribution of skills across different sectors."
        >
          {loading ? <LoadingState label="Loading sector data..." /> : <SectorDemandChart data={sectors} />}
        </AnalyticsCard>

        <AnalyticsCard
          label="Workforce Analysis"
          title="Skill Gap Analysis"
          description="Comparison of available skills and required skills."
        >
          {loading ? <LoadingState label="Loading skill-gap data..." /> : <SkillGapChart data={skillGap} />}
        </AnalyticsCard>
      </div>
    </DashboardLayout>
  );
};

export default Analytics;
