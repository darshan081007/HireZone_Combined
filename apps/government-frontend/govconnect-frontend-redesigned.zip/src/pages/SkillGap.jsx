import { useEffect, useState } from "react";
import { BarChart3, RefreshCw, TrendingUp, Users } from "lucide-react";

import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import Button from "../components/ui/Button";
import MetricCard from "../components/cards/MetricCard";
import Badge from "../components/ui/Badge";
import { LoadingState, ErrorState, EmptyState } from "../components/ui/States";

const API_URL = "http://localhost:8000";

function SkillGap() {
  const [skillGaps, setSkillGaps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchSkillGapData = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await fetch(
        `${API_URL}/api/government/skill-gap-analysis`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch skill-gap data");
      }

      const data = await response.json();

      const result = Array.isArray(data)
        ? data
        : data.skill_gaps || data.data || [];

      setSkillGaps(result);
    } catch (err) {
      console.error("Skill gap error:", err);
      setError("Unable to load skill-gap analysis.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSkillGapData();
  }, []);

  const getStudentCount = (item) =>
    Number(
      item.student_count ??
        item.students ??
        item.available ??
        item.student_total ??
        0
    );

  const getDemandCount = (item) =>
    Number(
      item.demand_count ??
        item.demand ??
        item.required ??
        item.industry_demand ??
        0
    );

  const getSkillGap = (item) => {
    const explicitGap = item.gap ?? item.skill_gap ?? item.difference ?? null;

    if (explicitGap !== null) {
      return Number(explicitGap);
    }

    return getDemandCount(item) - getStudentCount(item);
  };

  const skillsWithDemand = skillGaps.filter(
    (item) =>
      item.demand_count !== undefined ||
      item.demand !== undefined ||
      item.required !== undefined ||
      item.industry_demand !== undefined
  ).length;

  const identifiedGaps = skillGaps.filter((item) => getSkillGap(item) > 0)
    .length;

  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Government Intelligence"
        title="Skill Gap Analysis"
        description="Identify the difference between available student skills and industry-demanded skills to support targeted training and workforce development."
        icon={BarChart3}
      />

      {/* Summary cards */}
      <section className="mb-8 grid gap-5 md:grid-cols-3">
        <MetricCard
          icon={Users}
          title="Skills Analysed"
          description="Analysis"
          value={skillGaps.length}
          loading={loading}
        />
        <MetricCard
          icon={TrendingUp}
          title="Skills With Demand Data"
          description="Demand"
          value={skillsWithDemand}
          loading={loading}
        />
        <MetricCard
          icon={BarChart3}
          title="Potential Skill Gaps"
          description="Priority"
          value={identifiedGaps}
          loading={loading}
        />
      </section>

      {/* Skill gap table */}
      <section className="surface-card p-5 sm:p-7">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-navy-900">
              Skill Gap Breakdown
            </h2>
            <p className="mt-1 text-sm text-navy-500">
              Comparison of available skills and demand indicators.
            </p>
          </div>

          <Button variant="secondary" icon={RefreshCw} onClick={fetchSkillGapData}>
            Refresh
          </Button>
        </div>

        {loading && <LoadingState label="Loading skill-gap data..." />}

        {!loading && error && (
          <ErrorState message={error} onRetry={fetchSkillGapData} />
        )}

        {!loading && !error && skillGaps.length === 0 && (
          <EmptyState
            title="No skill-gap data available"
            description="Skill gap analysis will appear here once data is returned by the backend."
          />
        )}

        {!loading && !error && skillGaps.length > 0 && (
          <div className="thin-scroll overflow-x-auto">
            <table className="w-full min-w-[700px] text-left">
              <thead>
                <tr className="border-b border-border text-xs uppercase tracking-wider text-navy-400">
                  <th className="px-4 py-4 font-semibold">Skill</th>
                  <th className="px-4 py-4 font-semibold">Student Count</th>
                  <th className="px-4 py-4 font-semibold">Demand Count</th>
                  <th className="px-4 py-4 font-semibold">Skill Gap</th>
                  <th className="px-4 py-4 font-semibold">Status</th>
                </tr>
              </thead>

              <tbody>
                {skillGaps.map((item, index) => {
                  const skillName =
                    item.skill_name || item.skill || item.name || `Skill ${index + 1}`;

                  const studentCount = getStudentCount(item);
                  const demandCount = getDemandCount(item);
                  const gap = getSkillGap(item);

                  return (
                    <tr
                      key={`${skillName}-${index}`}
                      className="border-b border-border transition hover:bg-accent-50/60"
                    >
                      <td className="px-4 py-4 font-semibold text-navy-900">
                        {skillName}
                      </td>
                      <td className="px-4 py-4 text-navy-600">{studentCount}</td>
                      <td className="px-4 py-4 text-navy-600">{demandCount}</td>
                      <td
                        className={`px-4 py-4 font-semibold ${
                          gap > 0 ? "text-rose-600" : "text-emerald-600"
                        }`}
                      >
                        {gap}
                      </td>
                      <td className="px-4 py-4">
                        <Badge tone={gap > 0 ? "danger" : "success"}>
                          {gap > 0 ? "Gap Identified" : "Balanced"}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </DashboardLayout>
  );
}

export default SkillGap;
