import { ArrowLeft, MapPinOff } from "lucide-react";
import { useNavigate } from "react-router-dom";
import DashboardLayout from "../components/layout/DashboardLayout";
import Button from "../components/ui/Button";

function NotFound() {
  const navigate = useNavigate();

  return (
    <DashboardLayout>
      <section className="surface-card flex flex-col items-center gap-4 px-6 py-20 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent-100 text-accent-600">
          <MapPinOff size={30} />
        </div>

        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent-600">
          Error 404
        </p>

        <h1 className="text-2xl font-bold text-navy-900 sm:text-3xl">
          Page not found
        </h1>

        <p className="max-w-md text-sm leading-6 text-navy-500">
          The page you&apos;re looking for doesn&apos;t exist or may have been
          moved. Head back to the dashboard to continue.
        </p>

        <Button icon={ArrowLeft} onClick={() => navigate("/")} className="mt-2">
          Back to Dashboard
        </Button>
      </section>
    </DashboardLayout>
  );
}

export default NotFound;
