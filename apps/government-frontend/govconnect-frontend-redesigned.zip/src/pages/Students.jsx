import { useEffect, useState } from "react";
import { Users, Search, MapPin, GraduationCap, RefreshCw } from "lucide-react";

import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import Button from "../components/ui/Button";
import { EmptyState } from "../components/ui/States";
import { getStudents } from "../services/governmentService";

const Students = () => {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    setLoading(true);

    try {
      const response = await getStudents();

      const studentsData = Array.isArray(response.data) ? response.data : [];

      const uniqueStudents = Array.from(
        new Map(
          studentsData.map((student) => [student.student_id, student])
        ).values()
      );

      setStudents(uniqueStudents);
    } catch (error) {
      console.error("Failed to load students:", error);
      setStudents([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredStudents = students.filter((student) => {
    const query = search.toLowerCase();

    return (
      String(student.student_id).includes(query) ||
      (student.student_name || "").toLowerCase().includes(query) ||
      (student.college_name || "").toLowerCase().includes(query) ||
      (student.location || "").toLowerCase().includes(query)
    );
  });

  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Student Intelligence"
        title="Students"
        description="Browse registered students and their academic information."
        icon={Users}
        actions={
          <Button variant="secondary" icon={RefreshCw} onClick={loadStudents}>
            Refresh
          </Button>
        }
      />

      {/* Summary */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl bg-navy-900 p-6 text-white shadow-lg md:flex-row md:items-center">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10">
            <Users size={26} />
          </div>

          <div>
            <p className="text-sm text-white/70">Registered Students</p>
            <p className="mt-1 text-3xl font-bold">{students.length}</p>
          </div>
        </div>

        <div className="text-sm text-white/70">Student directory</div>
      </div>

      {/* Table card */}
      <section className="surface-card overflow-hidden">
        <div className="flex flex-col justify-between gap-4 border-b border-border p-5 md:flex-row md:items-center md:p-6">
          <div>
            <h2 className="text-lg font-bold text-navy-900">
              Student Directory
            </h2>
            <p className="mt-1 text-sm text-navy-500">
              {filteredStudents.length} student records displayed
            </p>
          </div>

          <div className="relative w-full md:w-80">
            <Search
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400"
            />
            <input
              type="text"
              placeholder="Search students..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              className="w-full rounded-xl border border-border bg-muted-50 py-2.5 pl-10 pr-4 text-sm text-navy-800 outline-none transition focus:border-accent-400 focus:ring-2 focus:ring-accent-100"
            />
          </div>
        </div>

        <div className="thin-scroll overflow-x-auto">
          <table className="w-full min-w-[700px] text-left">
            <thead className="bg-muted-50">
              <tr className="text-xs uppercase tracking-wider text-navy-400">
                <th className="px-6 py-4 font-semibold">Student ID</th>
                <th className="px-6 py-4 font-semibold">Name</th>
                <th className="px-6 py-4 font-semibold">College</th>
                <th className="px-6 py-4 font-semibold">Location</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-t border-border">
                    {Array.from({ length: 4 }).map((__, j) => (
                      <td key={j} className="px-6 py-4">
                        <div className="h-4 w-full max-w-[160px] animate-pulse rounded bg-muted-50" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : filteredStudents.length > 0 ? (
                filteredStudents.map((student) => (
                  <tr
                    key={student.student_id}
                    className="border-t border-border transition hover:bg-accent-50/60"
                  >
                    <td className="px-6 py-4">
                      <span className="rounded-lg bg-muted-50 px-3 py-1 text-sm font-semibold text-navy-700">
                        #{student.student_id}
                      </span>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-100 text-accent-700">
                          <GraduationCap size={17} />
                        </div>
                        <span className="font-semibold text-navy-800">
                          {student.student_name || "—"}
                        </span>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-sm text-navy-600">
                      {student.college_name || "—"}
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-navy-600">
                        <MapPin size={15} className="text-navy-400" />
                        {student.location || "—"}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="px-6 py-10">
                    <EmptyState
                      title="No students found"
                      description="Try a different search term, or check back once student records are available."
                    />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  );
};

export default Students;
