import { useEffect, useState } from "react";
import {
  Users,
  BriefcaseBusiness,
  Code2,
  Trophy,
  Building2,
  Megaphone,
  GraduationCap,
  BarChart3,
  Target,
  FileText,
} from "lucide-react";
import { Link } from "react-router-dom";

import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import MetricCard from "../components/cards/MetricCard";
import HubCard from "../components/cards/HubCard";
import { ErrorState } from "../components/ui/States";
import { getDashboardSummary } from "../services/api";

const statisticsConfig = [
  {
    key: "total_students",
    title: "Students",
    icon: Users,
    description: "Registered students",
  },
  {
    key: "total_recruiters",
    title: "Recruiters",
    icon: BriefcaseBusiness,
    description: "Registered recruiters",
  },
  {
    key: "total_skills",
    title: "Skills",
    icon: Code2,
    description: "Available skills",
  },
  {
    key: "active_challenges",
    title: "Active Challenges",
    icon: Trophy,
    description: "Currently active challenges",
  },
  {
    key: "active_government_jobs",
    title: "Government Jobs",
    icon: Building2,
    description: "Currently active jobs",
  },
  {
    key: "active_campaigns",
    title: "Campaigns",
    icon: Megaphone,
    description: "Active campaigns",
  },
];

const portalCards = [
  {
    title: "Student Intelligence",
    description:
      "Explore student profiles, skills, projects, evaluations, and achievements.",
    icon: GraduationCap,
    links: [
      { label: "Students", path: "/students" },
      { label: "Skills", path: "/skills" },
      { label: "Projects", path: "/projects" },
      { label: "Proof of Work", path: "/proof-of-work" },
      { label: "AI Evaluations", path: "/ai-evaluations" },
    ],
  },
  {
    title: "Recruiter Intelligence",
    description:
      "Analyze recruiters, hiring activities, demand skills, and recruitment trends.",
    icon: BriefcaseBusiness,
    links: [
      { label: "Recruiters", path: "/recruiters" },
      { label: "Hiring Activity", path: "/hiring-activity" },
      { label: "Demand Skills", path: "/demand-skills" },
      { label: "Challenges", path: "/challenges" },
      { label: "Recruitment Trends", path: "/recruitment-trends" },
    ],
  },
  {
    title: "Government Intelligence",
    description:
      "Monitor skill gaps, sectors, jobs, campaigns, reports, and regional data.",
    icon: Building2,
    links: [
      { label: "Skill Gap", path: "/skill-gap" },
      { label: "Sector Strength", path: "/sectors" },
      { label: "Low-Pursued Sectors", path: "/low-pursued-sectors" },
      { label: "Government Jobs", path: "/jobs" },
      { label: "Campaigns", path: "/campaigns" },
      { label: "Reports", path: "/reports" },
      { label: "Regional Distribution", path: "/regional-distribution" },
    ],
  },
];

const quickAccess = [
  {
    to: "/students",
    icon: Users,
    title: "View Students",
    description: "Browse student records.",
  },
  {
    to: "/recruiters",
    icon: BriefcaseBusiness,
    title: "View Recruiters",
    description: "Explore recruiter information.",
  },
  {
    to: "/skill-gap",
    icon: Target,
    title: "Skill Gap Analysis",
    description: "Identify talent shortages.",
  },
  {
    to: "/reports",
    icon: FileText,
    title: "Reports",
    description: "Access government reports.",
  },
];

function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      setLoading(true);
      setError("");

      const data = await getDashboardSummary();
      setDashboardData(data);
    } catch (err) {
      console.error("Dashboard loading error:", err);
      setError("Unable to load dashboard statistics.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Government Portal"
        title="Government Dashboard"
        description="Monitor student talent, recruitment activity, and employment opportunities across the ecosystem."
        icon={BarChart3}
      />

      {/* Welcome banner */}
      <section className="mb-8 overflow-hidden rounded-2xl bg-linear-to-r from-navy-900 to-accent-700 p-7 text-white shadow-lg sm:p-9">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-center">
          <div>
            <p className="mb-2 text-sm font-medium text-accent-100">
              Welcome to the analytics hub
            </p>
            <h2 className="text-2xl font-bold">
              Empowering India&apos;s Future Workforce
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-accent-50/90">
              Use data-driven insights to understand talent availability,
              identify skill gaps, and monitor employment opportunities.
            </p>
          </div>

          <BarChart3 className="h-14 w-14 flex-none text-white/70" />
        </div>
      </section>

      {error && (
        <div className="mb-8">
          <ErrorState message={error} onRetry={loadDashboardData} />
        </div>
      )}

      {/* Key statistics */}
      <section className="mb-10">
        <div className="mb-4">
          <h2 className="text-xl font-bold text-navy-900">Key Statistics</h2>
          <p className="mt-1 text-sm text-navy-500">
            Current platform statistics
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {statisticsConfig.map((stat) => (
            <MetricCard
              key={stat.key}
              icon={stat.icon}
              title={stat.title}
              description={stat.description}
              loading={loading}
              value={dashboardData?.[stat.key] ?? 0}
            />
          ))}
        </div>
      </section>

      {/* Portal hub */}
      <section className="mb-10">
        <div className="mb-4">
          <h2 className="text-xl font-bold text-navy-900">Analytics Hub</h2>
          <p className="mt-1 text-sm text-navy-500">
            Select a section to explore detailed government insights.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {portalCards.map((portal) => (
            <HubCard key={portal.title} {...portal} />
          ))}
        </div>
      </section>

      {/* Quick access */}
      <section>
        <h2 className="mb-4 text-xl font-bold text-navy-900">Quick Access</h2>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {quickAccess.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="surface-card p-5 transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-card-hover)]"
            >
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-accent-100 text-accent-600">
                <item.icon size={19} />
              </div>
              <h3 className="font-semibold text-navy-900">{item.title}</h3>
              <p className="mt-1 text-sm text-navy-500">{item.description}</p>
            </Link>
          ))}
        </div>
      </section>
    </DashboardLayout>
  );
}

export default Dashboard;
