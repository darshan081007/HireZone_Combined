import {
  Users,
  Building2,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  ArrowUpRight,
} from "lucide-react";

import DashboardLayout from "../components/layout/DashboardLayout";
import PageHeader from "../components/ui/PageHeader";
import Badge from "../components/ui/Badge";

const Recruiters = () => {
  return (
    <DashboardLayout>
      <PageHeader
        eyebrow="Industry Engagement"
        title="Recruiters"
        description="Monitor industry partners, hiring activity, and recruitment participation."
        icon={Users}
      />

      <div className="mb-8 overflow-hidden rounded-2xl bg-linear-to-r from-navy-900 to-accent-700 p-7 text-white shadow-lg md:p-9">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-center">
          <div>
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10">
              <Users size={26} />
            </div>

            <h2 className="text-2xl font-bold">Recruiters Module</h2>

            <p className="mt-3 max-w-xl text-sm leading-6 text-white/80">
              Monitor recruiters, hiring activity, industry demand, and
              recruitment campaigns.
            </p>
          </div>

          <div className="rounded-2xl border border-white/15 bg-white/10 px-6 py-5">
            <p className="text-sm text-white/70">Module Status</p>
            <Badge tone="success" className="mt-2">
              Available
            </Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        <InfoCard
          icon={<Building2 size={21} />}
          title="Industry Partners"
          description="Review participating organizations and recruiters."
        />

        <InfoCard
          icon={<BriefcaseBusiness size={21} />}
          title="Hiring Activity"
          description="Monitor recruitment and hiring-related activities."
        />

        <InfoCard
          icon={<ChartNoAxesCombined size={21} />}
          title="Industry Demand"
          description="Explore skill demand and recruitment trends."
        />
      </div>
    </DashboardLayout>
  );
};

const InfoCard = ({ icon, title, description }) => (
  <div className="surface-card p-6 transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-card-hover)]">
    <div className="mb-5 flex h-11 w-11 items-center justify-center rounded-xl bg-accent-100 text-accent-600">
      {icon}
    </div>

    <h3 className="text-base font-bold text-navy-900">{title}</h3>

    <p className="mt-2 text-sm leading-6 text-navy-500">{description}</p>

    <div className="mt-5 flex items-center gap-2 text-sm font-semibold text-accent-600">
      Explore <ArrowUpRight size={15} />
    </div>
  </div>
);

export default Recruiters;
