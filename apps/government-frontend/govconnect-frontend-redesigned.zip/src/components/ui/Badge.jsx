const tones = {
  accent: "bg-accent-100 text-accent-700",
  success: "bg-emerald-100 text-emerald-600",
  warning: "bg-amber-100 text-amber-600",
  danger: "bg-rose-100 text-rose-600",
  neutral: "bg-muted-50 text-navy-600 border border-border",
};

const Badge = ({ children, tone = "neutral", className = "" }) => {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]} ${className}`}
    >
      {children}
    </span>
  );
};

export default Badge;
