const variants = {
  primary:
    "bg-accent-600 text-white hover:bg-accent-700 shadow-sm shadow-accent-600/20",
  secondary:
    "border border-border-strong bg-white text-navy-800 hover:bg-muted-50",
  ghost: "text-navy-600 hover:bg-muted-50",
};

const Button = ({
  children,
  icon: Icon,
  variant = "primary",
  className = "",
  ...props
}) => {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent-500 focus-visible:outline-offset-2 ${variants[variant]} ${className}`}
      {...props}
    >
      {Icon && <Icon size={16} />}
      {children}
    </button>
  );
};

export default Button;
