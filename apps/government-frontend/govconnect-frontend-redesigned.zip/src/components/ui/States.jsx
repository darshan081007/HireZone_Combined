import { AlertCircle, Inbox, Loader2, RefreshCw } from "lucide-react";

export const LoadingState = ({ label = "Loading data..." }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-16">
    <Loader2 className="h-7 w-7 animate-spin text-accent-600" />
    <p className="text-sm text-navy-500">{label}</p>
  </div>
);

export const ErrorState = ({
  message = "Something went wrong while loading this data.",
  onRetry,
}) => (
  <div className="flex flex-col items-center gap-3 rounded-2xl border border-rose-100 bg-rose-50 px-6 py-10 text-center">
    <AlertCircle className="h-7 w-7 text-rose-600" />
    <p className="text-sm font-medium text-rose-700">{message}</p>
    {onRetry && (
      <button
        onClick={onRetry}
        className="mt-1 inline-flex items-center gap-2 rounded-xl bg-rose-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-rose-700"
      >
        <RefreshCw size={15} />
        Try again
      </button>
    )}
  </div>
);

export const EmptyState = ({
  title = "No data available",
  description = "There's nothing to show here yet.",
  icon: Icon = Inbox,
}) => (
  <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border-strong bg-muted-50 px-6 py-14 text-center">
    <Icon className="h-7 w-7 text-navy-400" />
    <p className="text-sm font-semibold text-navy-800">{title}</p>
    <p className="max-w-sm text-sm text-navy-500">{description}</p>
  </div>
);
