const PageHeader = ({ eyebrow, title, description, actions, icon: Icon }) => {
  return (
    <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
      <div className="flex items-start gap-4">
        {Icon && (
          <div className="hidden h-12 w-12 flex-none items-center justify-center rounded-2xl bg-accent-100 text-accent-600 sm:flex">
            <Icon size={22} />
          </div>
        )}

        <div>
          {eyebrow && (
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-accent-600">
              {eyebrow}
            </p>
          )}

          <h1 className="text-2xl font-bold tracking-tight text-navy-900 sm:text-3xl">
            {title}
          </h1>

          {description && (
            <p className="mt-2 max-w-2xl text-sm leading-6 text-navy-500">
              {description}
            </p>
          )}
        </div>
      </div>

      {actions && (
        <div className="flex w-fit flex-none items-center gap-3">
          {actions}
        </div>
      )}
    </div>
  );
};

export default PageHeader;
