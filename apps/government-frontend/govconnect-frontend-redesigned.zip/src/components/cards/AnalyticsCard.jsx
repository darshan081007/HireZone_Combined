// A consistent container for charts / analytics visualizations,
// used across the Analytics and dashboard pages.
const AnalyticsCard = ({ label, title, description, actions, children }) => {
  return (
    <section className="surface-card overflow-hidden">
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-border px-6 py-5">
        <div>
          {label && (
            <p className="text-xs font-semibold uppercase tracking-[0.12em] text-accent-600">
              {label}
            </p>
          )}
          <h2 className="mt-1 text-lg font-bold text-navy-900">{title}</h2>
          {description && (
            <p className="mt-1 text-sm text-navy-500">{description}</p>
          )}
        </div>

        {actions}
      </div>

      <div className="min-h-[280px] p-5 sm:p-6">{children}</div>
    </section>
  );
};

export default AnalyticsCard;
