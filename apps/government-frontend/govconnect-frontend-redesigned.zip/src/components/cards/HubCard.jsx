import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

// A "portal hub" card: a category of the platform with a short set of
// links into it. Used on the Dashboard to group related pages.
const HubCard = ({ title, description, icon: Icon, links = [] }) => {
  return (
    <div className="surface-card flex h-full flex-col p-6 transition hover:shadow-[var(--shadow-card-hover)]">
      <div className="mb-4 flex items-center gap-3">
        {Icon && (
          <div className="flex h-11 w-11 flex-none items-center justify-center rounded-xl bg-accent-100 text-accent-600">
            <Icon size={20} />
          </div>
        )}
        <h3 className="text-lg font-bold text-navy-900">{title}</h3>
      </div>

      <p className="mb-5 text-sm leading-6 text-navy-500">{description}</p>

      <div className="mt-auto space-y-1.5">
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className="group flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-navy-600 transition hover:bg-accent-50 hover:text-accent-700"
          >
            <span>{link.label}</span>
            <ArrowRight
              size={15}
              className="text-navy-300 transition group-hover:translate-x-0.5 group-hover:text-accent-600"
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default HubCard;
