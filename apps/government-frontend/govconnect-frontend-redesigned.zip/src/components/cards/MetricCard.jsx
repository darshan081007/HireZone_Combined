const MetricCard = ({ icon: Icon, title, value, description, loading }) => {
  return (
    <div className="surface-card p-5 transition hover:shadow-[var(--shadow-card-hover)]">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-sm font-medium text-navy-500">{title}</p>

          <p className="mt-3 text-3xl font-bold tracking-tight text-navy-900">
            {loading ? (
              <span className="inline-block h-8 w-16 animate-pulse rounded-md bg-muted-50" />
            ) : (
              value
            )}
          </p>

          {description && (
            <p className="mt-2 text-xs text-navy-400">{description}</p>
          )}
        </div>

        {Icon && (
          <div className="flex h-11 w-11 flex-none items-center justify-center rounded-xl bg-accent-100 text-accent-600">
            <Icon size={20} />
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricCard;
