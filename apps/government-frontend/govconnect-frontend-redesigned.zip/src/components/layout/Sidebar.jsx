import { NavLink } from "react-router-dom";
import { Landmark, X } from "lucide-react";
import { navigationGroups } from "../../config/navigation";

const NavItem = ({ item, onNavigate }) => {
  const Icon = item.icon;

  return (
    <NavLink
      to={item.path}
      end={item.end}
      onClick={onNavigate}
      className={({ isActive }) =>
        `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
          isActive
            ? "bg-accent-600 text-white shadow-sm shadow-accent-600/25"
            : "text-navy-600 hover:bg-accent-50 hover:text-accent-700"
        }`
      }
    >
      {({ isActive }) => (
        <>
          <Icon
            size={18}
            className={isActive ? "text-white" : "text-navy-400 group-hover:text-accent-600"}
          />
          <span>{item.name}</span>
        </>
      )}
    </NavLink>
  );
};

const SidebarContent = ({ onNavigate }) => (
  <div className="flex h-full flex-col">
    <div className="flex h-[72px] flex-none items-center gap-3 border-b border-border px-5">
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent-600 shadow-sm shadow-accent-600/30">
        <Landmark size={20} className="text-white" />
      </div>

      <div className="min-w-0">
        <p className="truncate text-[15px] font-bold leading-tight text-navy-900">
          GovConnect
        </p>
        <p className="truncate text-xs text-navy-500">
          Skill &amp; Employment Portal
        </p>
      </div>
    </div>

    <nav className="thin-scroll flex-1 overflow-y-auto px-3 py-5">
      {navigationGroups.map((group) => (
        <div key={group.label} className="mb-5 last:mb-0">
          <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-navy-400">
            {group.label}
          </p>

          <div className="space-y-1">
            {group.items.map((item) => (
              <NavItem key={item.path} item={item} onNavigate={onNavigate} />
            ))}
          </div>
        </div>
      ))}
    </nav>

    <div className="flex-none border-t border-border p-4">
      <div className="flex items-center gap-3 rounded-xl bg-muted-50 px-3 py-3">
        <span className="h-2 w-2 flex-none rounded-full bg-emerald-500" />
        <p className="text-xs font-medium text-navy-600">
          Government Representative
        </p>
      </div>
    </div>
  </div>
);

const Sidebar = ({ mobileOpen, onCloseMobile }) => {
  return (
    <>
      {/* Desktop sidebar — fixed */}
      <aside className="hidden w-[264px] flex-none border-r border-border bg-white lg:block">
        <div className="fixed h-screen w-[264px]">
          <SidebarContent />
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            aria-label="Close navigation menu"
            className="absolute inset-0 bg-navy-950/40 backdrop-blur-[2px]"
            onClick={onCloseMobile}
          />

          <div className="relative z-10 flex h-full w-[280px] max-w-[82vw] animate-fade-in-up flex-col bg-white shadow-xl">
            <button
              onClick={onCloseMobile}
              aria-label="Close navigation menu"
              className="absolute right-3 top-4 z-10 rounded-lg p-2 text-navy-500 hover:bg-muted-50"
            >
              <X size={18} />
            </button>

            <SidebarContent onNavigate={onCloseMobile} />
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;
