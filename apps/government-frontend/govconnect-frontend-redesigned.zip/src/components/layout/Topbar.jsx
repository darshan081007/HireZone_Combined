import { Menu, Landmark } from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { flatNavigation } from "../../config/navigation";

const Topbar = ({ onOpenMobile }) => {
  const location = useLocation();
  const current = flatNavigation.find((item) =>
    item.end ? location.pathname === item.path : location.pathname.startsWith(item.path)
  );

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-white/85 backdrop-blur-md">
      <div className="flex h-[72px] items-center gap-4 px-4 sm:px-6 lg:px-8">
        {/* Mobile menu button */}
        <button
          type="button"
          onClick={onOpenMobile}
          aria-label="Open navigation menu"
          className="rounded-xl border border-border-strong p-2.5 text-navy-700 lg:hidden"
        >
          <Menu size={19} />
        </button>

        {/* Brand — mobile only, sidebar already shows it on desktop */}
        <NavLink to="/" className="flex items-center gap-2.5 lg:hidden">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-600">
            <Landmark size={16} className="text-white" />
          </div>
          <span className="text-sm font-bold text-navy-900">GovConnect</span>
        </NavLink>

        {/* Current page breadcrumb */}
        <div className="hidden min-w-0 lg:block">
          <p className="text-xs font-medium uppercase tracking-[0.1em] text-navy-400">
            Government Intelligence Portal
          </p>
          <p className="truncate text-sm font-semibold text-navy-900">
            {current?.name ?? "Dashboard"}
          </p>
        </div>

        <div className="ml-auto flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-border bg-muted-50 px-3 py-1.5 sm:flex">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span className="text-xs font-medium text-navy-600">
              Live data
            </span>
          </div>

          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent-100 text-sm font-bold text-accent-700">
            GR
          </div>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
